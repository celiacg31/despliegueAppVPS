package com.cavanosa.virtual;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtualApplicationTests {

	@Test
	void contextLoads() {
	}

}
